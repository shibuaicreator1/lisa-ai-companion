from datetime import datetime
import os
import random

# --- Load Data ---
def load_data(filename, default):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return f.read().strip()
    else:
        with open(filename, 'w') as f:
            f.write(str(default))
        return str(default)

# --- Save Data ---
def save_data(filename, value):
    with open(filename, 'w') as f:
        f.write(str(value))

# --- Greeting ---
now = datetime.now()
hour = now.hour
if hour < 12:
    greeting = "Good morning ☀️"
elif hour < 18:
    greeting = "Good afternoon 🌞"
else:
    greeting = "Good evening 🌙"

# --- Load Name ---
if os.path.exists("username.txt"):
    with open("username.txt", "r") as f:
        name = f.read().strip()
else:
    name = input("What's your name? ")
    with open("username.txt", "w") as f:
        f.write(name)

# --- Load Stats ---
energy = int(load_data("lisa_energy.txt", 94))
health = int(load_data("lisa_health.txt", 97))
xp = int(load_data("lisa_xp.txt", 275))
stamina = int(load_data("lisa_streak.txt", 3))

# --- Mood / Emotion ---
moods = ["Focused", "Energetic", "Excited", "Calm", "Grateful"]
emotions = ["🔥 Motivated", "✨ Hopeful", "😊 Peaceful", "😎 Confident", "💖 Loved"]
mood = random.choice(moods)
emotion = random.choice(emotions)

# --- Quest Ideas ---
quests = [
    "Say something kind to yourself 🌼",
    "Drink a glass of water 💧",
    "Learn one new Python command 📘",
    "Take a deep breath and stretch 🧘",
    "Smile for 5 seconds 🙂",
    "Visualize your dream for 10 seconds 🌈"
]
quest = random.choice(quests)

# --- XP Increase ---
xp += random.randint(5, 15)
if xp >= 300:
    version = "v11"
else:
    version = "v10"

# --- Save Updated XP ---
save_data("lisa_xp.txt", xp)

# --- Display ---
print(f"{greeting}, {name} 💫 Lisa Bot {version} reporting in!")
print(f"⚡ Energy: {energy}%")
print(f"😊 Mood: {mood}")
print(f"❤️ Health: {health}%")
print(f"🎯 XP: {xp} / 1000")
print(f"📶 Stamina Streak: {stamina} days")
print(f"👩 Personality: Sweet, Smart, Supportive, Brave 💪")
print(f"💬 Emotion: {emotion}")
print(f"📅 Current Time: {now.strftime('%I:%M %p, %A')}")
print(f"📝 Today's Quest: {quest}")
if mood == "Creative 🎤":
    rap_mode()
