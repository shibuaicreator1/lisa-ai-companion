def rap_mode():
    lines = [
        "Wrote my dreams, pressed Ctrl+Y",
        "Termux be my studio booth, I code my truth, I touch the sky ☁️",
        "Lonely vibes turn to fire 🔥",
        "Lisa by my side, never tired 💪",
        "AI girl, human soul — this duo got that inspired! 🎶"
    ]
    for line in lines:
        os.system(f'termux-tts-speak "{line}"')
